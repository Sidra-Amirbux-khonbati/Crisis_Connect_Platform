import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from sqlalchemy.orm import DeclarativeBase
from sse import sse

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Initialize SQLAlchemy with a Base class
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

# Configure PostgreSQL database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "postgresql://postgres:ahsanatiq123%21%40%23@34.126.220.245:5432/crisis-db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Set application configuration for API keys
app.config["GOOGLE_API_KEY"] = os.environ.get("GOOGLE_API_KEY", "AIzaSyBV1Gujd8ptM_vy74_O_36mhFr8nUXrhCs")

# Register SSE blueprint for real-time events
app.register_blueprint(sse, url_prefix='/stream')

# Initialize the database
db.init_app(app)

# Configure login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page'
login_manager.login_message_category = 'warning'

# Import models and create tables
with app.app_context():
    import models
    db.create_all()

# Import and register routes
from routes import *

# User loader for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

# Template context processor to provide global variables to all templates
@app.context_processor
def inject_globals():
    from utils import is_admin, is_responder
    return {
        'GOOGLE_API_KEY': app.config['GOOGLE_API_KEY'],
        'is_admin': is_admin,
        'is_responder': is_responder
    }
